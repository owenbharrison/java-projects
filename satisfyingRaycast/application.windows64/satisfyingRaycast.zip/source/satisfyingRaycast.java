import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class satisfyingRaycast extends PApplet {

ArrayList<Circle> circles;

PVector middle;

int size = 220;
int intensity = 720;

public void setup(){
  
  middle = new PVector(width/2, height/2);
  circles = new ArrayList<Circle>();
  for(int i=0;i<15;i++){
    PVector vec = new PVector(random(width), random(height));
    circles.add(new Circle(vec.x, vec.y, random(15, 27)));
  }
}

public void draw(){
  background(0);
  ArrayList<PVector> stopPoints = new ArrayList<PVector>();
  middle.set(mouseX, mouseY);
  for(int a=0;a<intensity;a++){
    float angle = map(a, 0, intensity, 0, PI*2);
    PVector angleVector = PVector.fromAngle(angle);
    int shadowStart = -1;
    for(int l=0;l<size;l++){
      for(int p=0;p<circles.size();p++){
        Circle poly = circles.get(p);
        if(poly.contains(PVector.mult(angleVector, l).add(middle))){
          shadowStart = l;
          l = size;
          p = circles.size();
        }
      }
    }
    if(shadowStart!=-1)stopPoints.add(PVector.mult(angleVector, shadowStart).add(middle));
    else stopPoints.add(PVector.mult(angleVector, size).add(middle));
  }
  push();
  beginShape();
  noStroke();
  for(PVector sp:stopPoints){
    vertex(sp.x, sp.y);
  }
  endShape(CLOSE);
  pop();
  loadPixels();
  for(int x=0;x<width;x++){
    for(int y=0;y<height;y++){
      int index = x+y*width;
      if(brightness(pixels[index])>0){
        pixels[index] = color(map(dist(middle.x, middle.y, x, y), 0, size, 255, 0));
      }
    }
  }
  updatePixels();
  push();
  textAlign(CENTER, CENTER);
  text("FPS: "+round(frameRate), width/2, 10);
  pop();
}
class Circle{
  PVector pos;
  float radius;
  
  public Circle(float x, float y, float r){
    pos = new PVector(x, y);
    radius = r;
  }
  
  public void show(){
    push();
    circle(pos.x, pos.y, radius*2);
    pop();
  }
  
  public boolean contains(PVector pt){
    float x_ = pt.x-pos.x;
    float y_ = pt.y-pos.y;
    return x_*x_+y_*y_<radius*radius;
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "satisfyingRaycast" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
